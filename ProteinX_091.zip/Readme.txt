ProteinX 0.91

------------------------------------------------------
- Requirements
------------------------------------------------------

ProteinX requires Windows and DirectX 9.0c installed (make sure your DirectX has been updated since August 2005) (download DirectX at http://www.microsoft.com/directx).  It also requires a Shader 2.0+ graphics card.  The following is a list of graphic cards that support shader 2.0 and higher.

Geforce FX series
Geforce 6000 series
Geforce 7000 series
Radeon 9500-9800 series
Radeon X800 series
Radeon X1800 series
Radeon X1900 series

This release has been fully tested with a Nvidia Geforce 6800 GT graphics card and a ATI Radeon 9800 graphics card.

------------------------------------------------------
- PDB
------------------------------------------------------

ProteinX reads in PDB files, which can be downloaded from the PDB website http://www.rcsb.org  There are also some sample PDB files located in the "Protein Data Files" directory.

------------------------------------------------------
- Functions
------------------------------------------------------

ProteinX lets you perform a mutation on a selected amino acid residue, followed by energy minimization to find the lowest energy position of the new amino acid.  A more detail explanation will be added later to this readme.

The screenshot button switches to high resolution models before saving a screenshot to the ProteinX directory, resulting in sharper pictures.

------------------------------------------------------
- Controls
------------------------------------------------------

Holding the left mouse button down will move the protein around.
Holding the right mouse button down lets you rotate the protein.
The mouse scroll wheel will let you zoom in and out.
Holding the middle mouse button down lets you change the direction of the lighting.
Double clicking any atom with the left mouse button will select the residue the atom belongs to.

------------------------------------------------------
- Known Issues
------------------------------------------------------
- The window can only be resized before a protein file is opened, and can't be maximized or resized when you have a protein molecule on the screen.

------------------------------------------------------
- Contact
------------------------------------------------------

The author can be contacted at JoruusC@aol.com
